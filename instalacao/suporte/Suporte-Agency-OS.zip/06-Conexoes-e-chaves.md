# Conexões e chaves

Tudo aqui é opcional. O cofre, os 14 profissionais, as skills, o banco e o editor de vídeo funcionam sem nenhuma conexão. Para ligar depois da instalação: abrir o Claude no cofre (aba Code) e dizer `vamos conectar as ferramentas`. O Arquiteto guia uma por vez, com "pular" em cada uma.

**Regra de ouro:** chave se cola numa **janela nova do Terminal** (no Windows, do PowerShell), quando o Arquiteto mostrar o comando. Nunca no chat. Depois de ligar uma chave, **sair do app do Claude** (Mac: Cmd+Q; Windows: fechar a janela e conferir que ele saiu também da bandeja, perto do relógio) e abrir de novo, na aba Code, no cofre. Só assim ele enxerga a chave nova.

**Chave vazou (colou no chat, mandou em print)?** Revogue e crie outra: Groq em console.groq.com/keys (ícone de lixeira ao lado da chave › confirmar); Gemini em aistudio.google.com/app/apikey (menu da chave › excluir). Depois ligue a nova com "vamos conectar as ferramentas".

## Groq · transcrição da fala (grátis)

- Usa: video-to-text, legendas do editor de vídeo, o Espião.
- Criar: console.groq.com/keys › entrar com Google › "Create API Key" › copiar.
- Sem ela: aparece "Aviso (opcional): sem chave de transcrição (Groq)".

## Gemini · leitura da tela e voz de IA (grátis)

- Usa: ler slides, textos e números que aparecem nos vídeos; gerar narração com voz de IA no vídeo animado.
- Criar: aistudio.google.com/app/apikey › entrar com Google › "Criar chave de API" › copiar.
- Sem ela: a transcrição sai só com a fala, sem o que aparece na tela.
- Atenção: o serviço grátis do Google pode usar o conteúdo enviado. Para vídeo sigiloso (reunião, cliente), pedir para transcrever só a fala.

## Apify · coletas grandes (crédito grátis por mês, depois pago pelo uso)

- Usa: o Espião, quando a coleta é grande (Instagram, TikTok, Google Maps).
- Ligar (sem chave): criar a conta em console.apify.com/sign-up; numa janela nova do Terminal colar:
```
claude mcp add --scope user --transport http apify https://mcp.apify.com
```
  depois, no mesmo Terminal, rodar `claude`, digitar `/mcp`, escolher **apify** e entrar com a conta no navegador. Nenhum token fica em arquivo. Na próxima vez que abrir o app, o Apify já está ligado.

## Meta · Gestor de Tráfego e Biblioteca de Anúncios (grátis)

- Usa: o Gestor de Tráfego (campanhas) e o Espião (Biblioteca de Anúncios).
- Ligar: app do Claude › Configurações › **Conectores** › **Meta** › Conectar › entrar com a conta do Facebook que tem acesso aos anúncios e autorizar as contas de anúncio.
- Regras do dinheiro: o Gestor de Tráfego lê à vontade; **cria campanha só pausada**; ativar, mudar orçamento ou escalar só com o ok dela, a cada ação; nunca apaga campanha.

## Magnific · imagem e vídeo de IA (assinatura mensal)

- Usa: o Imagem e o Vídeo, para gerar e melhorar imagem e vídeo.
- Ligar: assinatura em magnific.ai e o conector no app do Claude (Configurações › Conectores). Gasto com geração só com o ok dela.

## Higgsfield · vídeo de IA (créditos, paga o que usar)

- Usa: o Vídeo e o Imagem, para gerar vídeo por IA.
- Ligar: conta e créditos em higgsfield.ai; a chave segue a regra de ouro (Terminal, nunca o chat). O Arquiteto mostra o comando.

## Pixel e rastreamento da página

- O profissional de Página e o Dev instalam o pixel na página quando ela der o **ID do pixel** (o número; nunca o token).
- A compra é registrada na plataforma de checkout dela (pixel e API de Conversões configurados lá).
