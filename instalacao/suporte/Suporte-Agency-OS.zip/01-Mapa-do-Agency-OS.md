# Mapa do Agency OS

## Em uma frase

Uma agência de marketing inteira que mora no computador da pessoa e trabalha dentro do Claude dela: ela conversa com o **Arquiteto**, e ele chama os **14 profissionais** para fazer copy, página, vídeo, criativo, anúncio e pesquisa.

## Agency OS e o nome técnico "Agency-Machine"

O Agency OS é construído sobre o Agency Machine. **Por dentro é o mesmo produto:** o mesmo instalador, o mesmo cofre, o mesmo Arquiteto e os mesmos 14 profissionais. Por isso, pastas, arquivos e algumas mensagens usam o **nome técnico** `Agency-Machine` (o zip `Agency-Machine-v6.zip`, a pasta `Cofres/Agency-Machine`, o log em `Downloads/Agency-Machine-instalador`). Isso é normal e não é erro: nunca peça para renomear essas pastas, porque o instalador, as atualizações e O Orquestrador procuram por esses nomes. Se a pessoa estranhar, explique em uma frase: "Agency OS é o nome do produto; Agency-Machine é o nome técnico da pasta".

## As peças

| Peça | O que é | Onde fica |
|---|---|---|
| **Claude (plano Pro ou Max)** | O escritório. Tudo roda na assinatura dela, sem pagar por peça. | Conta em claude.ai e o app do Claude no computador |
| **Aba Code do app do Claude** | Onde ela trabalha todo dia: conversa com o Arquiteto e os profissionais. É o Claude Code com tela amigável. | App do Claude › aba **Code**, com a pasta do cofre aberta |
| **O cofre** | A pasta onde a agência mora: o Arquiteto, os 14 profissionais, as habilidades (skills) deles, a memória e os projetos. Só arquivos de texto, leve. | `Cofres/Agency-Machine`, na pasta de usuário (Mac: `/Users/<nome>/Cofres/Agency-Machine`; Windows: `C:\Users\<nome>\Cofres\Agency-Machine`) |
| **A pasta gêmea** | A mídia pesada: vídeos brutos, vídeos prontos, imagens, anexos e o banco de efeitos. Fica ao lado do cofre para o Obsidian não ficar pesado. | `Cofres/Agency-Machine-Midia` (subpastas `Brutos`, `Exports`, `Anexos` e o banco) |
| **Obsidian** (grátis) | A janela para ler e organizar o cofre: projetos, entregas, memória. Opcional, recomendado. | App do Obsidian, abrindo a pasta `Cofres/Agency-Machine` como cofre |
| **Banco de mídia** | Sons, trilhas, efeitos e fundos que o editor de vídeo usa. Três versões: Básica, Intermediária, Completa. | Dentro da pasta gêmea |
| **O instalador** | O pacote baixado da área de membros (`Agency-Machine-v6.zip`). Instala tudo com uma linha no Terminal. | `Downloads/Agency-Machine-instalador` depois de descompactado (o log fica lá: `instalacao.log`) |
| **O Orquestrador** (opcional, vendido à parte) | O painel em que o Maestro, 5 diretores e o Revisor fazem a agência trabalhar sozinha, por tickets. | Instala por cima do Agency OS; o painel abre no navegador |

## O cofre por dentro (o que ela vê no Obsidian)

- `00-Comece-Aqui/`: os guias de início.
- `00-Entrada/`: caixa de entrada; o que chega solto vai para cá (o `/arrumar-cofre` organiza).
- `01-Base/`: a base de conhecimento da agência (copy, vídeo, páginas, tráfego, marca).
- `02-Projetos/`: um projeto por produto, oferta ou cliente. Dentro de cada um: `CLAUDE.md` (quem é o cliente, o que vende, tom e limites), `00-Direcao`, `01-Inteligencia`, `02-Estrategia`, `03-Marca`, `04-Entregas`, `05-Resultados`, `Materiais`.
- `03-Validados/`: o que foi ao ar e deu resultado, com o número.
- `04-Mercado/`: pesquisa de mercado que serve a vários projetos.
- `06-Marcas/`: identidade e tom de cada marca.
- `07-Dados/`: métricas e relatórios.
- `_Sistema/`: as regras da agência (não precisa mexer).
- `_backup/`: cópias antigas guardadas; nada é apagado.

## A equipe

- **Arquiteto:** o estrategista. A pessoa conversa com ele; ele entende, faz no máximo 3 perguntas, recomenda o caminho e chama os profissionais. Chama-se com `/arquiteto`.
- **Copy:** Copy de Oferta (página, VSL, anúncio, e-mail de venda), Copy de Conteúdo (posts, carrosséis, Reels, legendas), Copy de Conversa (WhatsApp, direct, fechamento).
- **Criação:** Marca (brand book, tom de voz), Imagem (criativos estáticos), Página (monta e confere a página), Vídeo (edição de vídeo falado, animado, cortes).
- **Tráfego e Redes:** Gestor de Tráfego (campanhas na Meta), Social Media (calendário, posts prontos, relatórios).
- **Inteligência e bastidor:** Espião de Mercado (pesquisa, concorrentes, anúncios, transcrição), Oráculo (lê os números), Dev (código, pixel, integrações), Mestre de Skills (avalia e instala ferramentas novas), Revisor (confere a peça antes do ok final).

## A jornada

1. **Antes de instalar** (Aula 1): Claude Pro ou Max e o app; Obsidian; as contas grátis do Groq, Gemini e Apify. → `02-Antes-de-instalar.md`
2. **Instalação** (Aula 2): uma linha no Terminal, uns 30 minutos. → `03-Instalacao-passo-a-passo.md`
3. **Primeiro dia** (Aula 3): abrir o cofre no Obsidian, abrir a aba Code, chamar o `/arquiteto`, criar o primeiro projeto. → `04-Primeiro-dia.md`
4. **Dia a dia:** pedir para o Arquiteto ou para os chats por área. → `05-Dia-a-dia.md`
5. **Crescendo:** conexões, banco maior, atualizações, O Orquestrador. → arquivos 06 a 09.
