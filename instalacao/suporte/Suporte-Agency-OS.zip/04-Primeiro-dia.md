# Primeiro dia

## 1. Abrir o cofre no Obsidian

1. Abrir o Obsidian › **Abrir pasta como cofre** ("Open folder as vault").
2. Escolher `Cofres/Agency-Machine` na pasta de usuário. **Só o cofre**, não a `Agency-Machine-Midia`.
3. Se perguntar se confia nos plugins do cofre: **Confiar** ("Trust author and enable plugins").
4. À esquerda devem aparecer `00-Comece-Aqui`, `01-Base`, `02-Projetos`...

**Obsidian em português:** engrenagem no canto de baixo à esquerda (Settings) › General (ou About) › **Language** › Português do Brasil › **Relaunch**.

A pasta não precisa ser criada nem arrastada: o instalador já deixou no lugar.

## 2. Abrir a agência no app do Claude

1. Abrir o app do Claude no computador.
2. Ir na aba **Code** (não a aba Chat: a conversa normal não enxerga o cofre).
3. Escolher o ambiente **deste computador** (local, não a nuvem) e a pasta `Cofres/Agency-Machine`. A pasta gêmea entra sozinha, não precisa escolher.
4. Quando o Claude pedir permissão para ler ou gravar um arquivo do cofre, é normal: **Permitir**. Para o `CLAUDE.md` de um projeto ele sempre pergunta antes; também **Permitir**.

Alternativa (sem o app): no Terminal, `cd ~/Cofres/Agency-Machine` e `claude` (Windows: abrir a pasta `Cofres\Agency-Machine` no Explorador, digitar `powershell` na barra de endereço, Enter, e rodar `claude`).

## 3. Chamar o Arquiteto

No chat da aba Code:
```
/arquiteto me faz um onboarding
```
Ele se apresenta, mostra a equipe e começa o primeiro projeto com ela.

## 4. O primeiro projeto

Um projeto é uma pasta por produto, oferta ou cliente. Pedir:
```
/novo-projeto
```
São 5 perguntas, uma por vez: nome do projeto; o que vende (e o preço); para quem (o cliente e a dor ou desejo dele); objetivo e prazo; como fala e o que nunca pode dizer. "Não sei ainda" vale: ele anota "a definir". No fim ele mostra o resumo e pergunta se pode criar `02-Projetos/<nome>/`: responder **pode**.

Depois: jogar logo, fotos e prints em `02-Projetos/<nome>/Materiais/` (pelo Obsidian ou pelo Finder/Explorador) e fazer o primeiro pedido, por exemplo:
```
Para o projeto <nome>, escreve 5 opções de headline para a página de vendas.
```

## 5. Dois jeitos de trabalhar

- **Jeito 1 · a Mesa do Arquiteto:** um chat só, com o `/arquiteto`. Ele chama os profissionais. Dá para usar sempre assim.
- **Jeito 2 · a agência em paralelo:** além da Mesa, abrir mais 3 chats na aba Code, no mesmo cofre: um com `/copy`, outro com `/criacao`, outro com `/trafego`, e fixar os quatro na barra lateral. Os chats não veem a conversa uns dos outros: cada time grava a entrega na pasta do projeto, e na Mesa ela pergunta `o que a equipe entregou?`.

Aviso: vários chats trabalhando ao mesmo tempo gastam o limite do plano do Claude mais rápido.
