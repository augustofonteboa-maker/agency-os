# Dia a dia

## Onde se trabalha

Sempre no app do Claude, aba **Code**, com a pasta `Cofres/Agency-Machine` aberta. Comece pelo `/arquiteto` ou pelo chat da área.

## Três regras que valem para tudo

1. **Diga o projeto.** "Para o projeto `<nome>`, ..." faz o Claude ler o cliente, o tom e os limites antes de começar.
2. **Rascunho fica no chat.** Nada vira arquivo aprovado até ela dizer "aprovado", "pode gravar" ou "salva". Antes de gravar, ele mostra onde vai gravar.
3. **Nada de inventar.** O que falta (depoimento, número, prova, preço) aparece marcado para ela preencher.

## Comandos

| Comando | Para quê |
|---|---|
| `/arquiteto` | Chamar o estrategista: "por onde começo", "monta o plano", "quero vender meu curso" |
| `/novo-projeto` | Criar a pasta de um produto, oferta ou cliente (5 perguntas) |
| `/copy` | Transformar o chat no chat fixo do time de Copy |
| `/criacao` | Transformar o chat no chat fixo do time de Criação (Marca, Imagem, Página, Vídeo) |
| `/trafego` | Transformar o chat no chat fixo do Tráfego e do Social Media |
| `/guardar-resultado` | Guardar uma peça que foi ao ar e deu resultado (com o número) em `03-Validados/` |
| `/arrumar-cofre` | Organizar arquivos soltos; mostra uma tabela e só move o que ela aprovar |
| "vamos conectar as ferramentas" | O Arquiteto liga Groq, Gemini, Meta e Apify, uma por vez |
| "instala a atualização" | Instalar um pacote de atualização (ver `08-Atualizacoes.md`) |

Não precisa saber o nome das skills: pedir com as próprias palavras, e o Claude escolhe.

## Quem faz o quê

| Profissional | Peça para |
|---|---|
| Espião de Mercado | Pesquisar mercado, concorrentes, anúncios e público; transcrever vídeos de referência |
| Copy de Oferta | Oferta, promessa, mecanismo, página de vendas, VSL, anúncio, e-mail de venda |
| Copy de Conteúdo | Posts, carrosséis, roteiros de Reels, pautas e calendário |
| Copy de Conversa | WhatsApp, direct, scripts de venda, recuperação de carrinho |
| Marca | Brand book, tom de voz, posicionamento, nome e identidade |
| Imagem | Criativos estáticos e imagens de anúncio e de conteúdo |
| Página | Montar e conferir a página de vendas ou o site (depois da copy aprovada) |
| Vídeo | Editar vídeo falado, vídeo 100% animado, cortes e motion |
| Social Media | Calendário e posts prontos (a pessoa publica) e relatórios de 24 h e 7 dias |
| Gestor de Tráfego | Campanhas na Meta: estrutura, público, criativos, leitura dos números |
| Dev | Código, integrações, pixel e rastreamento, automações |
| Mestre de Skills | Avaliar ou instalar uma skill ou ferramenta nova |
| Oráculo | Ler os números de todos os projetos e dizer o que funcionou |
| Revisor | Conferir uma peça antes do ok final |

## Pedidos prontos (trocar o que está entre `< >`)

- Copy: `Para o projeto <nome>, quero a copy de uma página de vendas para tráfego frio do Instagram. Pode fazer o briefing comigo pelo chat.`
- VSL: `Para o projeto <nome>, quero o roteiro de uma VSL de uns 12 minutos para tráfego frio. Antes da estrutura, me diga se a oferta está fraca.`
- Página: `Monta a página do projeto <nome> com a copy aprovada. A referência visual que eu amo é <link>. O logo está em Materiais.`
- Pesquisa: `Espião, estuda os 5 maiores concorrentes do projeto <nome> e os anúncios que eles rodam.`
- Transcrição: `Transcreve este vídeo: <link>`
- Vídeo falado: `Edita o vídeo Brutos/<arquivo>.mp4 da pasta de mídia: corta as pausas e os erros e põe legenda.`
- Vídeo animado só com áudio: `Faz um vídeo 100% animado com o áudio Brutos/<arquivo>.m4a para o projeto <nome>.`
- Anúncios: `Gestor de Tráfego, monta a campanha de vendas do projeto <nome> com os criativos aprovados. Cria pausada para eu revisar.`
- Resultado: `/guardar-resultado` e depois o número (cliques, vendas, custo por venda).

## Como a página vai para o ar

O profissional de Página monta e confere no navegador; **só publica quando ela pedir** ("coloca no ar"). Ele explica o serviço de hospedagem e o que precisa (conta, domínio) na hora.

## Postagem nas redes

Hoje o Social Media deixa o post pronto (vídeo ou imagem, legenda e horário) e **ela publica** pelo app do Instagram, ou **agenda** pelo Meta Business Suite (aí ele sai sozinho no horário). Postar direto pelo Claude não vem no Agency OS.

## Limites do plano do Claude

O plano Pro tem um limite de uso que reinicia de tempos em tempos (o próprio app mostra quando volta). Vídeo, página e vários chats ao mesmo tempo gastam mais. Bateu o limite: nada se perde (o que foi aprovado está gravado no cofre); é esperar voltar. O plano Max tem um limite maior (não ilimitado); trocar de plano é decisão e gasto dela. Dica: um chat por tarefa e pedir resumo antes de abrir outro.
