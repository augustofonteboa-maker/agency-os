# O Orquestrador

## O que é

O complemento que faz a agência trabalhar sozinha. Instala **por cima** do Agency OS. Ela continua conversando com o Arquiteto; agora ele passa o pedido para o **Maestro**, que divide entre **5 diretores** (Copy, Criação, Distribuição, Inteligência e Tecnologia) e os 14 profissionais, com o **Revisor** como portão de toda entrega. Tudo aparece num **painel** no navegador, em tickets. Ela aprova. Eles trabalham enquanto o computador está ligado. Os avisos no celular pelo Telegram são opcionais.

Vem também: as **Esteiras** (o caminho de cada tipo de pedido) e o **Mandato** (o que o Maestro pode fazer sem perguntar; começa vazio, ela decide o que liberar).

## Antes

- Agency OS instalado (versão 6 ou mais nova), no mesmo computador.
- Mac (Apple ou Intel) ou Windows 10/11 de 64 bits.
- A mesma conta do Claude (Pro ou Max). Com o Orquestrador, os agentes gastam o limite do plano trabalhando sozinhos: o Max é o mais indicado.

## Instalar (uns 10 minutos)

1. Baixar o `Orquestrador-v1.zip` da área de membros para Downloads.
2. Descompactar e entrar na pasta `Orquestrador-complemento`:
   - Mac (Terminal): `cd ~/Downloads && ditto -xk Orquestrador-v1.zip . ; cd Orquestrador-complemento`
   - Windows (PowerShell): `cd ~\Downloads; Expand-Archive Orquestrador-v1.zip . -Force; cd Orquestrador-complemento`
   (Se descompactou com dois cliques ou "Extrair tudo", a pasta pode ter ficado em `Downloads/Orquestrador-v1/Orquestrador-complemento`: entrar nela.)
3. Rodar `claude` e colar:
```
Instala O Orquestrador por cima do meu Agency Machine. Siga o CLAUDE.md desta pasta, uma etapa por vez, e me avise quando precisar de mim. No fim, me entreviste e crie o meu primeiro projeto.
```
4. O Claude confere o Agency OS, guarda **uma cópia do cofre inteiro** ao lado dele (`_backup-orquestrador`, uma vez por versão), instala o painel na versão certa, liga o Arquiteto ao Maestro e confere tudo. No fim, o Arquiteto faz umas 6 perguntas e cria o primeiro projeto.
5. **Quando o Claude pedir para gravar o `CLAUDE.md` do projeto: Permitir.**
6. Se o Mac pedir senha: é a senha do Mac (nada aparece ao digitar).

Pode rodar de novo quando quiser: nada é duplicado nem apagado.

## O painel

- Abre no navegador, no endereço que a conferência mostra no fim (normalmente `http://127.0.0.1:3200`). Só funciona no próprio computador.
- **Primeiro login:** se um ticket do Maestro aparecer travado, entrar com a conta do Claude no painel em **Configurações › Conexões de IA**.
- O painel fica instalado como um serviço do computador: liga sozinho quando o computador liga (pode levar um minuto). A equipe só trabalha com o computador ligado e acordado.

## Problemas comuns

- **"falta algo no Agency Machine":** (mensagem do instalador: significa que falta o Agency OS) instalar ou atualizar o Agency OS antes (versão 6 ou mais nova).
- **Agente travado em "Connect an account" ou sem conexão:** entrar com a conta do Claude em Configurações › Conexões de IA no painel. Se continuar, rodar a instalação do Orquestrador de novo (corrige sem apagar nada).
- **Painel não abre:** esperar um minuto depois de ligar o computador e tentar o endereço de novo. Se continuar, rodar a conferência do Orquestrador, que mostra o endereço e o que falta:
  - Mac: `cd ~/Downloads/Orquestrador-complemento && bash instalador/conferir.sh`
  - Windows: `cd ~\Downloads\Orquestrador-complemento; powershell -ExecutionPolicy Bypass -File instalador\conferir.ps1`
  Se ela acusar algo, rodar a instalação do Orquestrador de novo (não apaga nada).
- **Não apague a pasta `Orquestrador-complemento`:** a conferência, o desligar e a reinstalação usam ela.
- **Tickets parados:** o limite do plano do Claude pode ter acabado; espera voltar. Conferir também se o computador está ligado e sem dormir.
- **Erro na instalação:** ler o fim do `instalacao.log` da pasta `Orquestrador-complemento`; mandar ao suporte se não resolver.

## Desligar

Pedir ao Claude `desliga O Orquestrador`, ou:
- Mac: `cd ~/Downloads/Orquestrador-complemento && bash instalador/instalar-orquestrador.sh --desligar`
- Windows: `cd ~\Downloads\Orquestrador-complemento; powershell -ExecutionPolicy Bypass -File instalador\instalar-orquestrador.ps1 --desligar`

Nada é apagado: o Arquiteto volta a chamar os profissionais direto.

**Voltar o cofre para como era antes do Orquestrador** (raro; prefira só desligar): fechar o Obsidian e o Claude; **renomear** a pasta atual `Agency-Machine` para `Agency-Machine-antes-de-voltar` (não apagar: o que foi feito depois da cópia está nela); renomear a cópia de `_backup-orquestrador` para `Agency-Machine`. Na dúvida, chamar o suporte humano antes.
