# Antes de instalar

## Obrigatório

- **Computador:** Mac (chip Apple M1 ou mais novo, ou Intel; macOS 13 ou mais novo) ou Windows 10 (versão 1809 ou mais nova) ou 11, 64 bits. Windows ARM instala, mas o editor de vídeo fica mais lento e sem o recorte de fundo.
  - Ver a versão no Mac: menu Apple › Sobre Este Mac.
  - Ver no Windows: Configurações › Sistema › Sobre.
- **Espaço:** pelo menos **8 GB livres** no disco. Para o banco Completo, uns 12 GB livres.
- **Windows: uma conta de administrador** (a que instala programas). Numa conta comum, a janela "Deseja permitir alterações?" pede a senha de um administrador.
- **Conta do Claude com plano Pro ou Max** (claude.ai). É a única conta obrigatória.
- **O app do Claude no computador:** claude.ai/download. É nele, na aba Code, que ela vai trabalhar.
- **Uns 30 minutos** com o computador ligado e a internet estável.

Não precisa saber programar, não precisa de Cursor ou VS Code e não precisa instalar o Claude Code antes: o instalador instala.

## Recomendado (deixar pronto antes acelera)

- **Obsidian** (grátis): obsidian.md/download. Abre o cofre no fim da instalação.
- **As 3 contas que ligam o Espião no modo avançado.** Nada disso trava a instalação; dá para ligar depois.

| Conta | Para que serve | Custo | O que guardar |
|---|---|---|---|
| **Groq** | Transcrever a fala de vídeos e áudios (video-to-text e legendas) | Grátis, login com Google | Uma chave de API, criada em console.groq.com/keys |
| **Gemini** (Google AI Studio) | Ler o que aparece na tela dos vídeos (slides, textos, números) e gerar voz de IA | Grátis, login com Google | Uma chave de API, criada em aistudio.google.com/app/apikey |
| **Apify** | Coletas grandes de Instagram, TikTok e Google Maps | Crédito grátis por mês; acima dele, cobra pelo uso | Nada: só a conta (console.apify.com/sign-up). O Claude liga com o login, sem chave |

**Como guiar a criação de uma chave (Groq ou Gemini):** abrir o link com a conta Google, clicar em criar chave (Groq: "Create API Key"; AI Studio: "Criar chave de API" / "Create API key"), dar um nome qualquer ("agency"), copiar a chave e guardar num bloco de notas. Ela vai colar a chave no Terminal durante a instalação. Nunca no chat.

## Pode deixar para depois

- **Meta** (Gestor de Tráfego e Biblioteca de Anúncios): conector do app do Claude, com a conta do Facebook que tem acesso aos anúncios. → `06-Conexoes-e-chaves.md`
- **Magnific** (assinatura mensal) e **Higgsfield** (créditos): imagem e vídeo de IA para quem quer ir fundo.

## O que NÃO fazer

- Não escolher pasta dentro do Google Drive, iCloud, OneDrive ou Dropbox para o cofre. O editor de vídeo falha com arquivo na nuvem.
- Não descompactar o zip à mão nem mudar o nome dele: a linha de instalação procura o `Agency-Machine-v6.zip` (ou versão mais nova) em Downloads. Se o Safari descompactou sozinho (vira a pasta `Agency-Machine-instalador` em Downloads), tudo bem: a linha funciona igual.
