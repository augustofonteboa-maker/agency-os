# Vídeo, banco de mídia e a pasta gêmea

## Onde ficam os arquivos pesados

Na **pasta gêmea**, `Cofres/Agency-Machine-Midia`, ao lado do cofre. O Obsidian fica só com texto e não pesa.

| Pasta (dentro da gêmea) | O que vai |
|---|---|
| `Brutos/` | Os vídeos e áudios que ela gravou e quer editar (um por arquivo, com nome que diga o que é) |
| `Exports/` | Os vídeos prontos que o editor entrega (`-v001`, `-v002`...: cada ajuste vira uma versão nova, a anterior fica guardada) |
| `Anexos/` | Imagens e anexos |
| `Banco-Basica/`, `Banco-Intermediaria/` ou `Banco-Completa/` | O banco de mídia instalado |

Quando o Claude falar em "05-Midia", é essa pasta gêmea. **Não mover o cofre nem a gêmea para dentro do Google Drive, iCloud ou Dropbox**: o editor precisa dos arquivos no computador. Para compartilhar um vídeo pronto, copiar de `Exports` para onde quiser.

## O editor de vídeo (profissional Vídeo)

- **Vídeo falado** (ela olhando para a câmera, vertical): corta pausas, respiros e erros, põe legenda palavra por palavra e encaixa animações presas ao que ela fala.
- **Vídeo 100% animado:** ela grava só o áudio (m4a, mp3 ou wav), ou manda só o roteiro em texto (gera voz de IA; precisa da chave do Gemini).
- **Cortes:** tira os melhores trechos de um vídeo longo.
- **VSL de venda:** fluxo próprio, por partes, com aprovação dela.
- Música e efeitos só entram se ela pedir com essas palavras. O vídeo original nunca é alterado.
- Ainda não faz: vídeo deitado (16:9) com mais de uma câmera.
- Antes de aprovar: assistir. A conferência mede corte, legenda, ritmo e som, mas não mede gosto.

## O banco de mídia

| Versão | O que vem | Ocupa |
|---|---|---|
| Básica | Sons, trilhas, ícones e fundos essenciais | ≈ 0,4 GB |
| Intermediária | Banco do Estúdio inteiro + o melhor do Premium (sons curtos, LUTs, transições, molduras) | ≈ 2,5 GB |
| Completa | Banco do Estúdio inteiro + Premium inteiro | ≈ 5,5 GB |

- **As três versões vêm na compra**, sem custo extra. A diferença é só o espaço que ocupam.
- A instalação já baixa a Básica e sugere a maior que o computador aguenta.
- **Cada versão é um pacote completo e separado.** A Completa já traz tudo da Básica e da Intermediária. As "partes" são o mesmo pacote dividido em arquivos menores; não se somam entre versões.
- **Trocar de versão:** no Claude do cofre (aba Code), `troca o meu banco para a Completa` (ou Intermediária, ou Básica). Ele usa o instalador que ficou em `Downloads/Agency-Machine-instalador`, baixa o que precisar e ativa. A versão anterior fica no disco; para liberar espaço, pedir `libera o espaço dos bancos que não uso` (ele pergunta antes de tirar).
- **Pelo Terminal, se preferir:** Mac `cd ~/Downloads/Agency-Machine-instalador && python3 instalador/banco.py trocar completa` · Windows `cd ~\Downloads\Agency-Machine-instalador; python instalador\banco.py trocar completa`. Sem `trocar ...`, mostra a versão ativa e o espaço livre.
- **Não apague a pasta `Downloads/Agency-Machine-instalador`.** Se ela sumiu, baixar o zip do instalador de novo da área de membros e deixar em Downloads (não precisa reinstalar).
- **Plano B (download manual):** links em augustofonteboa-maker.github.io/agency-os/instalacao. Baixar **todas as partes da versão** para Downloads, sem descompactar, e pedir no Claude do cofre: `instala o banco <versão> que eu baixei` (ele roda o `trocar`, que acha os arquivos em Downloads, confere e instala).

## Problemas comuns do vídeo

- **"não achei o banco de mídia":** o banco não terminou de baixar. Pedir `instala o banco de mídia` ou usar o Plano B.
- **Vídeo não aparece para editar:** conferir se está em `Agency-Machine-Midia/Brutos/` e passar o nome exato do arquivo.
- **Do celular para o computador:** iPhone para Mac pelo AirDrop (o vídeo cai em Downloads; arrastar para `Brutos`); qualquer celular pelo cabo USB, ou pelo Google Drive/WhatsApp Web baixando o arquivo **original** (o WhatsApp comprime; prefira AirDrop, cabo ou Drive). `.mp4` e `.mov` (inclusive o HEVC do iPhone) funcionam.
- **Muito lento:** computador com pouca memória. Pedir para o Claude trocar o modo do editor para "intermediario" ou "basico".
- **Legenda errada ou sem legenda:** falta a chave do Groq (ver `06-Conexoes-e-chaves.md`).
