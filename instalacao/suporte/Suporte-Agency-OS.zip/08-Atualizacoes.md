# Atualizações

## Como funciona

De tempos em tempos sai um pacote `Atualizacao-AAAA-MM-DD.zip` na área de membros, com skills novas e melhoradas. Quem instala é o próprio Claude do cofre, com a skill `atualizar-agencia`. Os projetos, entregas, marcas, resultados, a `01-Base`, o `_Sistema/config.md` e o `CLAUDE.md` da raiz **não são tocados**. Nada se apaga: o que muda vai antes para `_backup/`.

## Passo a passo

1. Baixar o `Atualizacao-AAAA-MM-DD.zip` da área de membros e deixar em **Downloads** (ou na `00-Entrada` do cofre). Não descompactar.
2. Abrir o app do Claude › aba **Code** › pasta `Cofres/Agency-Machine`.
3. Pedir:
```
instala a atualização que eu baixei
```
4. Ele **simula primeiro** e conta: quantas skills entram, melhoram ou ficam iguais, o que vem do GitHub e se alguma skill que ela mexeu à mão vai ser trocada (a versão dela vai para `_backup/`). Ler e responder **pode**.
5. Ele aplica, confere e termina com três linhas: **Entrou**, **Backup** e **Falta**. Mostra também o `NOVIDADES.md`, com o que cada novidade faz e como pedir.

Se ela tem O Orquestrador, o próprio motor reimporta as skills no painel (o painel precisa estar aberto; se não estiver, ele avisa e dá para reimportar depois).

## Problemas

- **"O cofre não é do Agency Machine":** (mensagem do instalador, que usa o nome técnico) a pasta aberta não é o cofre. Abrir `Cofres/Agency-Machine` (a que tem o arquivo `.cofre-semente`).
- **"Versão do cofre antiga":** o pacote pede uma versão mais nova do Agency OS. Instalar antes os pacotes de atualização anteriores, em ordem de data. Se não der, chamar o suporte humano (não reinstalar por cima por conta própria).
- **"sha256 não bate":** o zip veio quebrado. Baixar de novo.
- **Sem internet:** dá para aplicar sem o que vem do GitHub; o Claude avisa e completa na próxima vez.
- **Quer voltar uma skill:** pedir ao Claude para trazer a versão de `_backup/atualizacao-<data>-<hora>/`.
- **Rodou duas vezes:** sem problema; na segunda, tudo aparece como igual.
