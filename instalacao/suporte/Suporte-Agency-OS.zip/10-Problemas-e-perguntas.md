# Problemas e perguntas frequentes

## No dia a dia

- **O Claude respondeu genérico, sem chamar o profissional nem a skill:** conferir se a pasta aberta na aba Code é `Cofres/Agency-Machine` (e não uma subpasta como `02-Projetos`). Se for, fechar o chat e abrir um novo; ou chamar direto: `/arquiteto`.
- **"Não achei o projeto":** dizer o nome exato da pasta em `02-Projetos/` ("para o projeto clinica-bem-estar").
- **Ele pede permissão toda hora:** é a proteção do Claude Code para gravar arquivos. Pode clicar em "Permitir" (ou "sempre permitir" para aquela pasta). Para o `CLAUDE.md` ele sempre pergunta.
- **Os comandos `/copy`, `/criacao`, `/trafego` ou `/arquiteto` não aparecem:** a pasta aberta não é o cofre, ou o cofre é de uma versão antiga. Abrir `Cofres/Agency-Machine`; se continuar, instalar a atualização mais nova.
- **O chat da Copy não sabe o que a Criação fez:** é assim mesmo; os chats não se veem. O que liga é a pasta do projeto: pedir na Mesa do Arquiteto `o que a equipe entregou?`.
- **Bateu o limite do plano:** nada se perde. Esperar o limite voltar (o app mostra quando). O plano Max tem limite maior, não ilimitado. Vários chats ao mesmo tempo, vídeo e página gastam mais.
- **Perdi um arquivo / ele gravou por cima:** o Claude não apaga nada no cofre; versões antigas ficam em `_backup/` e no histórico do git. Pedir ao Claude: `procura a versão anterior de <arquivo> no backup e no git`. Se foi ela que apagou pelo Obsidian ou pelo Finder/Explorador, olhar também a Lixeira.
- **O Obsidian ficou lento:** conferir se não há vídeos ou imagens grandes dentro do cofre (devem ficar na pasta gêmea). Pedir `/arrumar-cofre`.
- **Arquivos soltos e bagunça:** `/arrumar-cofre`. Ele mostra a tabela e só move o que ela aprovar.

## Perguntas frequentes

- **Preciso do Cursor ou do VS Code?** Não. O trabalho é no app do Claude, aba Code. (Quem já usa VS Code ou Cursor com a extensão do Claude Code também consegue, abrindo a pasta do cofre.)
- **Funciona no Windows?** Sim, Windows 10 ou 11 de 64 bits.
- **Preciso deixar o computador ligado?** Para o Agency OS, só enquanto estiver trabalhando. Com O Orquestrador, a equipe trabalha enquanto o computador estiver ligado e acordado.
- **Funciona no celular?** O trabalho é no computador. No celular dá para pensar com o Arquiteto num Projeto do Claude (guia em `00-Comece-Aqui/Arquiteto-no-app.md` no cofre) e levar o briefing para o computador.
- **Posso usar em dois computadores?** A licença é pessoal. Em outro computador seu, instale de novo pela área de membros; os projetos ficam no cofre de cada máquina.
- **Posso compartilhar com um sócio, time ou cliente?** Não. A licença é pessoal e intransferível (ver `_Sistema/Licenca-de-Uso.md` no cofre). Cada pessoa precisa da própria compra.
- **Qual plano do Claude?** Pro funciona; Max dá mais folga, principalmente com vídeo, vários chats e O Orquestrador.
- **O Claude posta no meu Instagram?** Não no Agency OS: o Social Media deixa o post pronto e você publica pelo Instagram ou agenda pelo Meta Business Suite.
- **Onde baixo o instalador, as atualizações e O Orquestrador?** Na área de membros da compra (app.hub.la, "Acessar minhas compras").
- **Onde estão os links e a linha de instalação?** augustofonteboa-maker.github.io/agency-os/instalacao.

## Como mandar um print e o log

- **Print:** Mac `Cmd + Shift + 4` e selecionar a área (a imagem vai para a Mesa); Windows `Win + Shift + S` e selecionar (fica copiado para colar). Depois, colar ou arrastar a imagem no chat do Suporte.
- **Log:** abrir a pasta `Downloads/Agency-Machine-instalador` (ou `Orquestrador-complemento`), dar dois cliques no `instalacao.log` (abre no TextEdit ou no Bloco de Notas), ir até o fim e copiar as últimas 40 linhas, ou mandar o arquivo inteiro.

## Aba Code: a pasta não aparece

Na aba Code, o Claude precisa trabalhar **neste computador** (ambiente local), não na nuvem. Ao abrir uma sessão, escolher a opção local ("Este computador"/"Local") e a pasta `Cofres/Agency-Machine`. Se aparecer só a opção de nuvem ou de repositório, atualizar o app do Claude e abrir de novo.

## Reinstalar ou consertar

Colar a mesma linha de instalação de novo (ver `03-Instalacao-passo-a-passo.md`). Ela não copia por cima do cofre que já existe nem apaga nada: só refaz o que faltou e roda a conferência.

## Suporte humano

Depois de duas tentativas sem resolver, ou para compra, acesso e reembolso: **suporte@agencymachine.com.br**, com o print do erro, o `instalacao.log` (do Agency OS: `Downloads/Agency-Machine-instalador`; do Orquestrador: `Orquestrador-complemento`) e se é Mac ou Windows.
