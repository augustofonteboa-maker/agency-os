# Instalação passo a passo

## Resumo

1. Baixar o `Agency-Machine-v6.zip` na área de membros e deixar em **Downloads**, sem descompactar.
2. Abrir o Terminal (Mac) ou o PowerShell (Windows) e colar **uma linha**.
3. Entrar com a conta do Claude e responder **Sim** quando perguntar se confia na pasta.
4. Responder 3 perguntas (nome, pasta, e-mail da compra) e acompanhar. O Claude para quando precisa da mão dela.
5. No fim, a conferência tem que dizer **"Tudo certo"**.

## 1. Abrir o Terminal

- **Mac:** Cmd + Espaço, digitar `Terminal`, Enter.
- **Windows:** menu Iniciar, digitar `PowerShell`, Enter (o "Windows PowerShell" normal, não precisa ser como administrador).

## 2. A linha

**Mac:**
```
cd ~/Downloads && z=$(ls -t | grep -m1 '^Agency-Machine-v.*\.zip$'); [ -n "$z" ] && ditto -xk "$z" .; bash Agency-Machine-instalador/instalador/comecar.sh
```

**Windows:**
```
cd ~\Downloads; $ProgressPreference='SilentlyContinue'; $z = gci Agency-Machine-v*.zip | sort LastWriteTime | select -Last 1; if ($z) { Expand-Archive $z.FullName . -Force }; powershell -ExecutionPolicy Bypass -File Agency-Machine-instalador\instalador\comecar.ps1
```

A linha descompacta o pacote, instala o Claude Code se faltar (1 a 2 minutos; no Windows, também o Git) e abre o Claude já dentro da pasta, com o pedido de instalação.

**Na primeira vez:** o Claude pede login. Abre o navegador, ela entra com a conta do Claude (Pro ou Max) e volta ao Terminal. Depois ele pergunta se confia na pasta: **Sim** (ou "Yes, proceed").

Se o Claude abrir parado, sem começar, ela escreve no Terminal: `instala o Agency Machine` (o comando usa o nome técnico, é assim mesmo)

## 3. As 3 perguntas

1. **O nome dela:** os agentes vão chamá-la assim.
2. **Onde fica o cofre:** aceitar o padrão (a pasta `Cofres` na pasta de usuário). Nunca dentro do Google Drive, iCloud, OneDrive ou Dropbox.
3. **O e-mail da compra:** vai na licença do cofre. Se não quiser dizer, segue como "nao-informado"; não trava nada.

## 4. O que ele instala, em ordem

| Etapa | O que acontece | Tempo | Mão humana |
|---|---|---|---|
| Ferramentas | Python, Node, ffmpeg, git, uv, yt-dlp (só o que faltar). No Mac, sem Homebrew, tudo vai para a pasta dela (`~/.local`), nada no sistema. | 2 a 15 min | Mac: janela "Ferramentas de Linha de Comando" → **Instalar**. Windows: "Deseja permitir alterações?" → **Sim** (Git, Node, ffmpeg) |
| Cofre | Copia o cofre (uns 40 MB) para `Cofres/Agency-Machine` e põe o nome dela nas instruções | 1 min | Mac pode perguntar permissão de pasta → **Permitir** |
| Pasta gêmea | Cria `Cofres/Agency-Machine-Midia` ao lado do cofre e aponta o cofre para ela | segundos | nada |
| Git | Inicia o histórico do cofre (nada sai do computador) | segundos | nada |
| Editor de vídeo | Prepara o ambiente do editor (baixa uns 400 MB) | 3 a 8 min (parece parado: é normal) | nada |
| Banco de mídia | Baixa a versão Básica (0,4 GB, com retomada) e, olhando o disco e a memória, sugere a Intermediária ou a Completa | 1 a 10 min | Aceitar ou não a versão maior |
| Extras | Editor extra Hypit (open-source, de terceiros; mostra o link da licença), conectores grátis do Espião e do radar | 1 a 3 min | nada |
| Conexões | Pergunta se quer conectar Groq, Gemini, Apify agora ou depois | depende | Colar as chaves numa **janela nova** do Terminal (nunca no chat) |
| Conferência | Roda a checagem final | segundos | Ler: tem que dizer **"Tudo certo"** |

"Aviso (opcional)" no fim, sobre chaves ou conexões que ficaram para depois, é normal e não é erro.

## 5. Avisos que aparecem e o que fazer

- **Mac · "Ferramentas de Linha de Comando" / "Command Line Tools":** clicar **Instalar**, aceitar, esperar de 5 a 15 minutos. O instalador espera junto. Não precisa de senha.
- **Mac · "Operation not permitted" no log ou na tela:** Ajustes do Sistema › Privacidade e Segurança › **Acesso total ao disco** › ligar o **Terminal** (se não estiver na lista, botão + e escolher Aplicativos › Utilitários › Terminal; o Mac pede a senha ou o Touch ID e pode mostrar "Sair e Reabrir": pode aceitar) › fechar o Terminal inteiro (Cmd+Q) › abrir de novo › colar a mesma linha.
- **Mac · pede senha:** é a senha do Mac; ao digitar, nada aparece na tela. É normal.
- **Windows · "Deseja permitir que este aplicativo faça alterações no seu dispositivo?":** **Sim**, uma vez para cada ferramenta. Se pedir usuário e senha, a conta não é de administrador: entrar com a senha de um administrador do computador.
- **Windows · Windows Defender ou antivírus perguntando:** **Permitir**. A cópia pode ficar lenta com o antivírus; é normal.
- **Windows · falta o winget:** abrir a Microsoft Store, procurar "Instalador de Aplicativo" (App Installer), atualizar e colar a linha de novo.
- **Windows · "a execução de scripts foi desabilitada":** a linha já usa `-ExecutionPolicy Bypass` só para aquele script; conferir se ela colou a linha inteira, sem cortar.
- **Banco não baixou (internet caiu, Drive bloqueou):** o instalador mostra o Plano B. Os links ficam em augustofonteboa-maker.github.io/agency-os/instalacao, seção do banco. Ela baixa **todas as partes da versão** para Downloads, sem descompactar, e pede no Claude: `instala o banco <versão> que eu baixei`. Ou, no Terminal, na pasta do instalador: `python3 instalador/banco.py trocar basica` (Windows: `python instalador\banco.py trocar basica`).
- **Parece travado:** o editor de vídeo e o banco ficam minutos sem mostrar nada. Esperar 10 minutos antes de achar que travou.
- **Fechou o Terminal, caiu a internet, deu erro no meio:** colar a mesma linha de novo. Tudo pode rodar de novo sem estragar nada; ele continua de onde parou.
- **"claude: command not found" / "claude não é reconhecido":** fechar o Terminal inteiro, abrir de novo e colar a linha outra vez (o Terminal novo enxerga o Claude recém-instalado).
- **Login do Claude não abre o navegador:** o Terminal mostra um link; copiar e abrir no navegador.
- **"No such file or directory" logo depois de colar a linha:** o zip não está em Downloads (ou foi renomeado, ex.: `Agency-Machine-v6 (1).zip`). Conferir a pasta Downloads: deixar só um zip com o nome `Agency-Machine-v6.zip` (ou a pasta `Agency-Machine-instalador`, se o Safari já descompactou) e colar de novo.

## 6. Como saber que deu certo

- A conferência disse **"Tudo certo"**.
- Existem as duas pastas: `Cofres/Agency-Machine` e `Cofres/Agency-Machine-Midia`.
- Próximo passo: `04-Primeiro-dia.md`.

## 7. Onde ver o erro exato

O arquivo `instalacao.log`, na pasta `Downloads/Agency-Machine-instalador`. Para mandar ao suporte, abrir o arquivo e copiar o fim dele (as últimas 40 linhas) ou mandar o arquivo inteiro. Ver a conferência de novo, a qualquer hora:
- Mac: `cd ~/Downloads/Agency-Machine-instalador && bash instalador/conferir.sh`
- Windows: `cd ~\Downloads\Agency-Machine-instalador; powershell -ExecutionPolicy Bypass -File instalador\conferir.ps1`
